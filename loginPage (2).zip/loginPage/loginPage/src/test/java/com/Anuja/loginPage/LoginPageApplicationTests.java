package com.Anuja.loginPage;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LoginPageApplicationTests {

	@Test
	void contextLoads() {
	}

}
