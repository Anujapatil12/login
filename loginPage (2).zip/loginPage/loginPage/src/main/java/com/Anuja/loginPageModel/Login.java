package com.Anuja.loginPageModel;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class Login {
	
	@Id
	String pass;
	String username;
	public Login() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Login(String pass, String username) {
		super();
		this.pass = pass;
		this.username = username;
	}
	public String getPass() {
		return pass;
	}
	public void setPass(String pass) {
		this.pass = pass;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	@Override
	public String toString() {
		return "Login [pass=" + pass + ", username=" + username + "]";
	}
	

}
