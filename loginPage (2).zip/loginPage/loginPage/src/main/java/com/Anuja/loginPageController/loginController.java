package com.Anuja.loginPageController;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import com.Anuja.loginPageModel.Login;




@Controller
public class loginController {
	
	
	@Autowired
	SessionFactory sf;


	@RequestMapping("/")
		public String login() {
		
			return "login";
			
		}
	
		@RequestMapping("/login")
		public ModelAndView login(Login login) {
			Session ss=sf.openSession();
			Transaction tx=ss.beginTransaction();
			ModelAndView mv = new ModelAndView();
			mv.setViewName("index");
			System.out.println("record inserted");
			ss.save(login);
			tx.commit();
			return mv;
		}

		
	}


